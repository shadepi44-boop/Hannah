# Hannah Android app — text chat only

This is an Android source project connected to the existing Firebase project. It contains no photo/video/voice upload feature and does not require Firebase Storage or a paid Firebase plan.

## Included
- Purple and white Android interface
- Email/password sign-in using Firebase Authentication
- Real-time text messages in Firestore
- Hannah-only welcome screen and “Let's Chat” button
- GitHub Actions workflow to build a debug APK in the cloud

## Important configuration
- The Android application ID is `Com.isaac.Hannah` to match the existing Firebase Android app registration.
- The welcome screen is shown to the second account UID currently configured in the app: `RErcrn2jlDMSR5eG4pmBRtOkdER2`.
- Firestore collection: `messages`
- Message fields: `senderId`, `text`, `type`, `createdAt`

## Build APK using a phone
1. Create/sign in to a GitHub account.
2. Create a new repository named `Hannah` and upload the contents of this folder (the files inside the folder, not the outer ZIP) to the repository's `main` branch.
3. Open the repository's **Actions** tab and enable Actions if GitHub asks.
4. Open **Build Hannah APK** and tap **Run workflow**. Wait until the run finishes successfully.
5. Open that completed run, find **Artifacts**, and download `Hannah-debug-APK`. Extract the downloaded artifact ZIP to get `app-debug.apk`.
6. Install the APK on Android. If Android asks, allow the browser/file manager to install unknown apps for this one install.

## If the cloud build fails
Open the failed workflow run and read the first red error. The project uses GitHub Actions to build, so no laptop or local Android Studio is required. Do not upgrade Firebase or add a payment method for this text-only app.

## Account safety
Use the two Firebase accounts already created. Do not share their passwords. If the second account is only temporary, Hannah can use her own email account later after adding it to Firebase Authentication and updating the allowed UID in Firestore rules and the app's `HANNAH_UID` constant.
