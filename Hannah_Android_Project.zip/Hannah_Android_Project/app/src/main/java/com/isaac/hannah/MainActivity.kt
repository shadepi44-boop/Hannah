package com.isaac.hannah

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.Send
import androidx.compose.material.icons.filled.Favorite
import androidx.compose.material.icons.filled.Logout
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.google.firebase.Timestamp
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.firestore.FirebaseFirestore
import com.google.firebase.firestore.ListenerRegistration
import com.google.firebase.firestore.Query
import com.google.firebase.firestore.ServerTimestamp
import java.text.SimpleDateFormat
import java.util.Locale

private val Purple = Color(0xFF7042C5)
private val PalePurple = Color(0xFFF2ECFF)
private val Ink = Color(0xFF281B3B)
private const val HANNAH_UID = "RErcrn2jlDMSR5eG4pmBRtOkdER2"

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { HannahApp() }
    }
}

data class ChatMessage(
    val senderId: String = "",
    val text: String = "",
    val type: String = "text",
    val createdAt: Timestamp? = null
)

@Composable
private fun HannahApp() {
    val auth = remember { FirebaseAuth.getInstance() }
    var currentUser by remember { mutableStateOf(auth.currentUser) }
    var email by remember { mutableStateOf("") }
    var password by remember { mutableStateOf("") }
    var error by remember { mutableStateOf("") }
    var loading by remember { mutableStateOf(false) }

    MaterialTheme(
        colorScheme = lightColorScheme(
            primary = Purple,
            onPrimary = Color.White,
            secondary = Color(0xFFB69AEF),
            background = Color(0xFFFFFBFF),
            surface = Color.White
        )
    ) {
        Surface(Modifier.fillMaxSize(), color = Color(0xFFFFFBFF)) {
            if (currentUser == null) {
                LoginScreen(
                    email = email,
                    onEmail = { email = it },
                    password = password,
                    onPassword = { password = it },
                    error = error,
                    loading = loading,
                    onLogin = {
                        if (email.isBlank() || password.isBlank()) {
                            error = "Enter your email and password."
                        } else {
                            loading = true
                            error = ""
                            auth.signInWithEmailAndPassword(email.trim(), password)
                                .addOnCompleteListener { task ->
                                    loading = false
                                    if (task.isSuccessful) {
                                        currentUser = auth.currentUser
                                    } else {
                                        error = task.exception?.localizedMessage
                                            ?: "Couldn't sign in. Check the details and try again."
                                    }
                                }
                        }
                    }
                )
            } else {
                val user = currentUser!!
                if (user.uid == HANNAH_UID) {
                    var enteredChat by remember { mutableStateOf(false) }
                    if (!enteredChat) {
                        WelcomeScreen(onChat = { enteredChat = true })
                    } else {
                        ChatScreen(userId = user.uid, onLogout = {
                            auth.signOut()
                            currentUser = null
                            enteredChat = false
                        })
                    }
                } else {
                    ChatScreen(userId = user.uid, onLogout = {
                        auth.signOut()
                        currentUser = null
                    })
                }
            }
        }
    }
}

@Composable
private fun LoginScreen(
    email: String,
    onEmail: (String) -> Unit,
    password: String,
    onPassword: (String) -> Unit,
    error: String,
    loading: Boolean,
    onLogin: () -> Unit
) {
    Column(
        Modifier.fillMaxSize().padding(28.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.Center
    ) {
        Box(
            Modifier.size(82.dp).background(PalePurple, CircleShape),
            contentAlignment = Alignment.Center
        ) {
            Icon(Icons.Filled.Favorite, contentDescription = null, tint = Purple, modifier = Modifier.size(42.dp))
        }
        Spacer(Modifier.height(18.dp))
        Text("Hannah", fontSize = 32.sp, fontWeight = FontWeight.Bold, color = Purple)
        Text("Just us. Just messages. 💜", color = Ink, fontSize = 15.sp)
        Spacer(Modifier.height(28.dp))
        OutlinedTextField(
            value = email, onValueChange = onEmail, label = { Text("Email") },
            singleLine = true, keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Email),
            modifier = Modifier.fillMaxWidth()
        )
        Spacer(Modifier.height(12.dp))
        OutlinedTextField(
            value = password, onValueChange = onPassword, label = { Text("Password") },
            singleLine = true, visualTransformation = PasswordVisualTransformation(),
            modifier = Modifier.fillMaxWidth()
        )
        if (error.isNotBlank()) {
            Spacer(Modifier.height(10.dp))
            Text(error, color = MaterialTheme.colorScheme.error, fontSize = 13.sp)
        }
        Spacer(Modifier.height(18.dp))
        Button(onClick = onLogin, enabled = !loading, modifier = Modifier.fillMaxWidth().height(52.dp)) {
            if (loading) CircularProgressIndicator(modifier = Modifier.size(20.dp), color = Color.White)
            else Text("Log in")
        }
    }
}

@Composable
private fun WelcomeScreen(onChat: () -> Unit) {
    Column(
        Modifier.fillMaxSize().background(PalePurple).padding(28.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.Center
    ) {
        Icon(Icons.Filled.Favorite, contentDescription = null, tint = Purple, modifier = Modifier.size(70.dp))
        Spacer(Modifier.height(24.dp))
        Text("Hannah 💜", fontSize = 32.sp, color = Purple, fontWeight = FontWeight.Bold)
        Spacer(Modifier.height(22.dp))
        Text(
            "Hey babe 🥹💜 Always remember, I love you. ❤️♾️ No matter the distance, you're always close to my heart. 💕",
            fontSize = 20.sp, lineHeight = 30.sp, color = Ink, textAlign = TextAlign.Center
        )
        Spacer(Modifier.height(30.dp))
        Button(onClick = onChat, modifier = Modifier.fillMaxWidth().height(54.dp)) {
            Text("Let's Chat 💜", fontSize = 17.sp)
        }
    }
}

@Composable
private fun ChatScreen(userId: String, onLogout: () -> Unit) {
    val db = remember { FirebaseFirestore.getInstance() }
    var messages by remember { mutableStateOf(listOf<Pair<String, ChatMessage>>()) }
    var draft by remember { mutableStateOf("") }
    var error by remember { mutableStateOf("") }

    DisposableEffect(Unit) {
        val listener: ListenerRegistration = db.collection("messages")
            .orderBy("createdAt", Query.Direction.ASCENDING)
            .addSnapshotListener { snapshot, e ->
                if (e != null) {
                    error = e.localizedMessage ?: "Couldn't load messages."
                } else if (snapshot != null) {
                    messages = snapshot.documents.mapNotNull { doc ->
                        val msg = doc.toObject(ChatMessage::class.java)
                        if (msg != null) doc.id to msg else null
                    }
                }
            }
        onDispose { listener.remove() }
    }

    Column(Modifier.fillMaxSize().background(Color(0xFFFFFBFF))) {
        Row(
            Modifier.fillMaxWidth().background(Purple).padding(horizontal = 16.dp, vertical = 14.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Icon(Icons.Filled.Favorite, contentDescription = null, tint = Color.White)
            Spacer(Modifier.width(10.dp))
            Column(Modifier.weight(1f)) {
                Text("Hannah", color = Color.White, fontSize = 21.sp, fontWeight = FontWeight.Bold)
                Text("Private chat 💜", color = Color.White.copy(alpha = 0.85f), fontSize = 12.sp)
            }
            IconButton(onClick = onLogout) {
                Icon(Icons.Filled.Logout, contentDescription = "Log out", tint = Color.White)
            }
        }

        if (error.isNotBlank()) {
            Text(error, color = MaterialTheme.colorScheme.error, modifier = Modifier.padding(12.dp))
        }

        if (messages.isEmpty()) {
            Box(Modifier.weight(1f).fillMaxWidth().padding(24.dp), contentAlignment = Alignment.Center) {
                Text("Your conversation starts here. 💜", color = Purple, textAlign = TextAlign.Center)
            }
        } else {
            LazyColumn(
                modifier = Modifier.weight(1f).fillMaxWidth().padding(horizontal = 12.dp),
                contentPadding = PaddingValues(vertical = 12.dp),
                verticalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                items(messages, key = { it.first }) { item ->
                    val msg = item.second
                    val mine = msg.senderId == userId
                    Row(
                        Modifier.fillMaxWidth(),
                        horizontalArrangement = if (mine) Arrangement.End else Arrangement.Start
                    ) {
                        Column(
                            Modifier.widthIn(max = 300.dp)
                                .background(if (mine) PalePurple else Color(0xFFF4F1F7), RoundedCornerShape(18.dp))
                                .padding(horizontal = 14.dp, vertical = 10.dp)
                        ) {
                            Text(msg.text, color = Ink, fontSize = 16.sp)
                            msg.createdAt?.let { timestamp ->
                                Text(
                                    SimpleDateFormat("h:mm a", Locale.getDefault()).format(timestamp.toDate()),
                                    color = Ink.copy(alpha = 0.55f), fontSize = 10.sp,
                                    modifier = Modifier.align(Alignment.End).padding(top = 4.dp)
                                )
                            }
                        }
                    }
                }
            }
        }

        Row(
            Modifier.fillMaxWidth().background(Color.White).padding(10.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            OutlinedTextField(
                value = draft,
                onValueChange = { if (it.length <= 10000) draft = it },
                modifier = Modifier.weight(1f),
                placeholder = { Text("Write a message…") },
                maxLines = 4
            )
            Spacer(Modifier.width(8.dp))
            IconButton(
                onClick = {
                    val textToSend = draft.trim()
                    if (textToSend.isNotEmpty()) {
                        val data = hashMapOf<String, Any>(
                            "senderId" to userId,
                            "text" to textToSend,
                            "type" to "text",
                            "createdAt" to com.google.firebase.firestore.FieldValue.serverTimestamp()
                        )
                        db.collection("messages").add(data)
                            .addOnSuccessListener { draft = ""; error = "" }
                            .addOnFailureListener { e -> error = e.localizedMessage ?: "Message didn't send." }
                    }
                },
                enabled = draft.trim().isNotEmpty(),
                modifier = Modifier.size(50.dp).background(Purple, CircleShape)
            ) {
                Icon(Icons.AutoMirrored.Filled.Send, contentDescription = "Send", tint = Color.White)
            }
        }
    }
}
